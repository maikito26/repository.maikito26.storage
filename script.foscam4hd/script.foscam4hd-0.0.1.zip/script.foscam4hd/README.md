# script.foscam4hd
KODI add-on for a Foscam HD cameras

Windows10
KODI 15.1
Foscam F19831w & F19804p model IP Cameras with firmware v2.11.1.118