# script.foscam
KODI add-on for a Foscam HD cameras
- A fork of the original creation intended to support the following environment.

Windows10
KODI 15.1
Foscam F19831w & F19804p model IP Cameras with firmware v2.11.1.118