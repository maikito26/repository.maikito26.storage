# script.foscam
XBMC add-on for a Foscam HD camera
-
